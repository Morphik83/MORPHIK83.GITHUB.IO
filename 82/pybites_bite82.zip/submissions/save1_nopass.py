from enum import Enum

THUMBS_UP = '👍'  # in case you go f-string ...

# move these into an Enum:
BEGINNER = 2
INTERMEDIATE = 3
ADVANCED = 4
CHEATED = 1

